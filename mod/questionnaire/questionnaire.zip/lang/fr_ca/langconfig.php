<?php
$string['parentlanguage'] = 'fr_utf8';
?>
