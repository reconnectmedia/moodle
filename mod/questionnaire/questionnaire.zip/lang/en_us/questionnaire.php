<?PHP // $Id: questionnaire.php,v 1.2 2011/05/09 13:41:31 joseph_rezeau Exp $ 

$string['dateformatting'] = 'Use the month/day/year format, e.g. for March 14th, 1945:&nbsp; <strong>3/14/1945</strong>';
$string['strfdate'] = '%m/%d/%Y';
$string['strfdateformatcsv'] = 'm/d/Y H:i:s';
?>